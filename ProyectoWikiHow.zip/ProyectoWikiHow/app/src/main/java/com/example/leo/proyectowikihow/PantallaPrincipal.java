package com.example.leo.proyectowikihow;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PantallaPrincipal extends AppCompatActivity {

    private Button btOlvidoPass, btRegistro, btInicioSes, btWeb;
    public static EditText usu;
    private EditText pass;
    private WebView webV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal);

        btOlvidoPass = (Button) findViewById(R.id.btOlvido);
        btRegistro = (Button) findViewById(R.id.btRegistrar);
        btInicioSes = (Button) findViewById(R.id.btInicio);
        btWeb = (Button) findViewById(R.id.btPaginaWeb);

        usu = (EditText) findViewById(R.id.etUsu);
        pass = (EditText) findViewById(R.id.etPass);
    }

    public void limpiar(View v) {
        usu.setText("");
        pass.setText("");
    }

    public void alta(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "admin", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase(); //permisos de escritura a la base de datos
        String usuario = usu.getText().toString();
        String password = pass.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("usuario", usuario);
        registro.put("password", password);
        db.insert("miembros", null, registro);
        db.close();
        limpiar(v);
        Toast.makeText(this, "se agregaron los datos a la base", Toast.LENGTH_LONG).show();
    }



    public void iniciarSesion(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "admin", null, 1);
        SQLiteDatabase db = admin.getReadableDatabase();
        Intent intent = new Intent(PantallaPrincipal.this, Tutoriales.class);
        String user = usu.getText().toString();
        String contr = pass.getText().toString();
        Cursor fila = db.rawQuery("select usuario , password from miembros where usuario = " +"'" + user + "'" + "AND password = " + "'" + contr + "'", null);
        if (fila.moveToFirst()){
            Bundle b = new Bundle();
            b.putString("Nombre", usu.getText().toString());
            intent.putExtras(b);
            startActivity(intent);
        }else{
            Toast.makeText(this, "no se pudo iniciar sesion", Toast.LENGTH_LONG).show();
        }
        fila.close();
    }

    public void recuperarContraseña(View v){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "admin", null, 1);
        SQLiteDatabase db = admin.getReadableDatabase();
        Intent intent = new Intent(PantallaPrincipal.this, Tutoriales.class);
        String user = usu.getText().toString();
        Cursor fila = db.rawQuery("select password from miembros where usuario = " +"'" + user + "'", null);
        if (fila.moveToFirst()){
            pass.setText(fila.getString(0));
        }else{
            Toast.makeText(this, "Nombre de usuario incorrecto", Toast.LENGTH_LONG).show();
        }
        fila.close();
    }

    public void pantallaWeb(View v){
        Intent intent = new Intent(PantallaPrincipal.this, PaginaWeb.class);
        Bundle b = new Bundle();
        startActivity(intent);
    }

    public void pantallaInicio(View v){
        Intent intent = new Intent(PantallaPrincipal.this, Tutoriales.class);
        Bundle b = new Bundle();
        startActivity(intent);
    }


}
