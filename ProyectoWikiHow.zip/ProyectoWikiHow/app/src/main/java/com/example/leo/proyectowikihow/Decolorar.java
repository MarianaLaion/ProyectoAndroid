package com.example.leo.proyectowikihow;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Decolorar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decolorar);
    }
}
