package com.example.leo.proyectowikihow;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Tutoriales extends AppCompatActivity {

    private Button btSens, btRas, btCambioLlanta, btDecol, btCorb;
    private TextView txSaludo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutoriales);

        btSens = (Button) findViewById(R.id.btSensible);
        btRas = (Button) findViewById(R.id.btRasurar);
        btCambioLlanta = (Button) findViewById(R.id.btLlanta);
        btDecol = (Button) findViewById(R.id.btDecolorar);
        btCorb = (Button) findViewById(R.id.btCorbata);

        txSaludo = (TextView) findViewById(R.id.tvHola);
        Bundle b = this.getIntent().getExtras();
        txSaludo.setText("hola " + b.get("Nombre"));

    }

    public void pantallaSensible(View v){
        Intent intent = new Intent(Tutoriales.this, RasurarseSensible.class);
        Bundle b = new Bundle();
        startActivity(intent);
    }

    public void pantallaRasurar(View v){
        Intent intent = new Intent(Tutoriales.this, RasurarseSencillo.class);
        Bundle b = new Bundle();
        startActivity(intent);
    }

    public void pantallaLlanta(View v){
        Intent intent = new Intent(Tutoriales.this, CambiarLlanta.class);
        Bundle b = new Bundle();
        startActivity(intent);
    }

    public void pantallaDecolorar(View v){
        Intent intent = new Intent(Tutoriales.this, Decolorar.class);
        Bundle b = new Bundle();
        startActivity(intent);
    }

    public void pantallaCorbata(View v){
        Intent intent = new Intent(Tutoriales.this, NudoCorbata.class);
        Bundle b = new Bundle();
        startActivity(intent);
    }


}
